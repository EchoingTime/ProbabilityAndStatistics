% Plotter, will plot the quadratic equation 
% Dante Anzalone's Plotter Script
clc, clearvars, close all
y = linspace(10,50); % Generates 100 y-coordinates range from 10 through 50
a = 5; % Shape and direction of a parabola (negative for a downward 
% parabola and positive for an upward parabola)
b = .2; % Position of the vertex and the slope of the parabola
c = -1; % y-inctercept of the parabola

z = (b * b) - (4*a*c); % b^2 - 4ac
z = z + (4 * a * c) + ((4 * a).*y); % b^2 - 4ac + 4ay for all y values
z = sqrt(z); % squares z
x = (-b + z) / (2 * a); % finds value of x one, finishing quadratic equation
x2 = (-b - z) / (2 * a); % finds value of x2, finishing quadratic equation 2

% Creating the plot! 

figure(1)
plot(x, y, 'o', 'MarkerFaceColor','r','MarkerSize',4)
xlabel('x-Coordinates'), ylabel('y-Coordinates')
title(['MatLab Plotter - Quadratic Equation'])
grid on
hold on
plot(x2, y, 'o', 'MarkerFaceColor','r','MarkerSize',4)