% MatLab Salter, will salt given data
% Dante Anzalone's Salter Script
clc, clearvars, close all
% Code from Anzalone's Plotter Script (Look at Figure 7.1 for full view of
% the code
y = linspace(10,50); a = 5; b = .2; c = -1; z = (b * b) - (4*a*c); z = z + (4 * a * c) + ((4 * a).*y); z = sqrt(z); x = (-b + z) / (2 * a); x2 = (-b - z) / (2 * a);

figure(1), plot(x, y, 'o', 'MarkerFaceColor','r','MarkerSize',4), xlabel('x-Coordinates'), ylabel('y-Coordinates'), title('MatLab Salter - Quadratic Equation'), grid on, hold on, plot(x2, y, 'o', 'MarkerFaceColor','r','MarkerSize',4)
hold on
% Now to salt the data!

% MatLab Allows users to do this easily enough! The bounds to change y
% values will be 5 through 25
a = 5; b = 25; % Random range - used MathWorks 
% Help Center https://www.mathworks.com/help/matlab/math/floating-point-numbers-within-specific-range.html

t = (b - a).*rand(1, 100) + a;
y = y + t;

plot (x,y, 's', 'MarkerFaceColor', 'y', 'MarkerSize',4)
hold on
plot (x2,y, 's', 'MarkerFaceColor', 'y', 'MarkerSize',4)