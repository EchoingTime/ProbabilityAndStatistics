% MatLab Smoother, will smooth data
% Dante Anzalone's Smoother Script (Figure 7.1 for below's Original Plotter Data 
clc, clearvars, close all

% Initial Plotter Commands
y = linspace(10,50); a = 5; b = .2; c = -1; z = (b * b) - (4*a*c); z = z + (4 * a * c) + ((4 * a).*y); z = sqrt(z); x = (-b + z) / (2 * a); x2 = (-b - z) / (2 * a);
% Salter Commands
figure(1), a = 5; b = 25; t = (b - a).*rand(1, 100) + a; y = y + t; plot (x,y, 's', 'MarkerFaceColor', 'r', 'MarkerSize',4), hold on, plot (x2,y, 's', 'MarkerFaceColor', 'r', 'MarkerSize',4), xlabel('x-Coordinates'), ylabel('y-Coordinates'), title('MatLab Smoother - Quadratic Equation'), grid on, hold on

% Now to Smooth the data!
% MatLab provides a smoothing method of its own, cutting back the work and
% lines needed!
% Help Center https://www.mathworks.com/help/matlab/ref/smoothdata.html

y2 = smoothdata(y, "gaussian", 10)

plot (x,y2, '*', 'MarkerFaceColor', 'k', 'MarkerSize',5), hold on, plot (x2,y2, '*', 'MarkerFaceColor', 'k', 'MarkerSize',5)